#define ACTOR_BROWSER
#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#define DIRECTINPUT_VERSION 0x0800
#include <windows.h>

#include <dinput.h>
#include <atomic>
#include <mutex>
#include <thread>
#include <sstream>
#include <cmath>
#include <map>
#include "catalog.h"
#include "importhook.h"
#include "hookregistry.h"
#include "nativeui.h"
static bool nativeDrawing=true;
static HookRegistry hookRegistry;
#include "actorvalues.h"
#include "vectorfonts.h"
#include "controller.h"
#include "controllease.h"
#include "nvsemessaging.h"

// Uses only the four-field version prefix of the public NVSE query ABI.
struct NVSEVersionPrefix { uint32_t nvseVersion,runtimeVersion,editorVersion,isEditor; };
struct PluginInfo { uint32_t infoVersion; const char* name; uint32_t version; };
static controls::ScriptInputAPI controlButtons;
static controls::Lease controlLease;
static BrowserPlayerControls* controlAPI=nullptr;
static BrowserScriptAPI* controlScripts=nullptr;
static void* menuModeScript=nullptr;
static bool controlsReady=false;
static unsigned controlInitAttempts=0;static DWORD controlRetryAt=0;
static std::atomic<bool> nativeLoopActive{false};
static bool gameMenuActive(){
 BrowserScriptResult result{};
 return !menuModeScript||!controlScripts->call(menuModeScript,nullptr,nullptr,&result,0)||result.type!=1||result.number!=0;
}
static HMODULE moduleHandle;
static std::wstring root,iniPath;
static std::wstring bridgePath;
static UINT sessionToken=0;
static int quantity=1;
static bool controllerPrompts=false;
static pad::Decoder controllerDecoder;
static WORD controllerOpenButton=XINPUT_GAMEPAD_DPAD_RIGHT;
static HANDLE browserGate=nullptr;
static bool ownsBrowserGate=false;
static uint32_t themeRGB=0xFFBD42;
static void drawControllerFocus();
static bool acquireBrowser(){
 if(!browserGate){auto name=L"Local\\LukeBrowsers-"+std::to_wstring(GetCurrentProcessId());browserGate=CreateSemaphoreW(nullptr,1,1,name.c_str());}
 if(!browserGate||WaitForSingleObject(browserGate,0)!=WAIT_OBJECT_0)return false;
 ownsBrowserGate=true;return true;
}
static void releaseBrowser(){if(ownsBrowserGate){ReleaseSemaphore(browserGate,1,nullptr);ownsBrowserGate=false;}}
static uint32_t tintPixel(unsigned brightness){
 return (((themeRGB>>16)&255)*brightness/255<<16)|(((themeRGB>>8)&255)*brightness/255<<8)|((themeRGB&255)*brightness/255);
}
static bool livePlugins=false;
static std::atomic<bool> opened{false};
static std::atomic<DWORD> blockUntil{0};
static std::atomic<long> mouseDX{0},mouseDY{0},wheelDelta{0};
static std::mutex catalogMutex;
static ib::Catalog catalog;
static std::vector<std::wstring> plugins;
static std::vector<size_t> visible;
static std::string status="Select a plugin to browse actors introduced by that file.";
static std::atomic<bool> loading{false};
static int pluginIndex=-1,pluginScroll=0,itemScroll=0,selected=-1,category=0,focus=0;
static bool showTemplates=false;
static bool showOverrides=false,settingsPage=false,dirty=true;
static bool valuesPage=false; static int avIndex=0,avScroll=0,targetMode=0;
static std::string valueInput="100",targetName="Select a target",baseValue="--",currentValue="--";
static unsigned valueRequest=0; static bool snapshotReady=false;
static unsigned listDirty=0;
static std::vector<uint32_t> backdrop;
static int backdropScale=0;
static uint64_t backdropBuilds=0,canvasBuilds=0,listBuilds=0;
static int backgroundOpacity=72,dragScroll=0;
static float mouseSpeed=1.6f,dragOffset=0;
static bool menuSounds=true,pickupSounds=true;
static int lastClickItem=-1;static DWORD lastClickTime=0;static float lastClickX=0,lastClickY=0;
constexpr int ListTop=190,RowHeight=29,ListRows=14,ListHeight=ListRows*RowHeight;
static int searchScope=2; // 1=plugins, 2=actors, independent of keyboard focus.
static std::string query,pluginQuery;
static std::vector<int> filteredPlugins;
static UINT hotkey=VK_F10;
static std::atomic<bool> monitorActive{false},toggleQueued{false};
static std::atomic<DWORD> lastFrameTick{0},toggleTick{0};
static bool consumeToggle(DWORD now) {return toggleQueued.exchange(false)&&now-toggleTick.load()<2000;}
static float cursorX=550,cursorY=350;
static bool previousKeys[256]{};
static HWND gameWindow=nullptr;
static HBRUSH background;
static constexpr int font=1,titleFont=2,smallFont=3,detailFont=4,glowFont=5,capsFont=6;
static VectorFont vanillaBody,vanillaHeading;
static auto& vanillaGlow=vanillaBody;
static void logLine(const char* text);
static void loadMenuFont(VectorFont& face,const std::wstring& file,const wchar_t* family,int weight,const wchar_t* backup) {
 try {
  face.load(file,family,weight);
  uint32_t scratch=0;face.draw(&scratch,1,1,0,0,1,1,"A",22,RGB(255,255,255));
 }catch(const std::exception& error){
  logLine(error.what());logLine("Using system font fallback; browser remains available.");
  face.useSystemFont(backup,weight);
 }
}
static void loadMenuFonts(const std::wstring& directory) {
 loadMenuFont(vanillaHeading,directory+L"BarlowCondensed-Bold.ttf",L"Barlow Condensed",FW_BOLD,L"Arial");
 loadMenuFont(vanillaBody,directory+L"ShareTechMono-Regular.ttf",L"Share Tech Mono",FW_NORMAL,L"Consolas");
 uint32_t scratch=0;
 for(int scale=1;scale<=3;++scale)for(int size:{17,22,27,32}){
  if(size==22||size==32)vanillaHeading.draw(&scratch,1,1,0,0,1,1,"A",size*scale,RGB(255,255,255));
  if(size!=32)vanillaBody.draw(&scratch,1,1,0,0,1,1,"A",size*scale,RGB(255,255,255));
 }
}

static HDC canvas;
static HBITMAP bitmap;
static void* pixels;

static ib::Inflate inflateFn=nullptr;
static std::atomic<bool> frameSeen{false},inputReady{false};
constexpr int Width=1120,Height=700;
static int renderScale=2;
static void destroyCanvas() {
 if(canvas)DeleteDC(canvas);canvas=nullptr;
 if(bitmap)DeleteObject(bitmap);bitmap=nullptr;pixels=nullptr;


}
static int rasterWidth() {return Width*renderScale;}
static int rasterHeight() {return Height*renderScale;}
static bool createCanvas() {
 destroyCanvas();
 BITMAPINFO bi{};bi.bmiHeader.biSize=sizeof(BITMAPINFOHEADER);bi.bmiHeader.biWidth=rasterWidth();bi.bmiHeader.biHeight=-rasterHeight();bi.bmiHeader.biPlanes=1;bi.bmiHeader.biBitCount=32;bi.bmiHeader.biCompression=BI_RGB;
 canvas=CreateCompatibleDC(nullptr);bitmap=CreateDIBSection(canvas,&bi,DIB_RGB_COLORS,&pixels,nullptr,0);
 if(!canvas||!bitmap||!pixels)return false;
 SelectObject(canvas,bitmap);SetMapMode(canvas,MM_ANISOTROPIC);
 SetWindowExtEx(canvas,Width,Height,nullptr);SetViewportExtEx(canvas,rasterWidth(),rasterHeight(),nullptr);
 return true;
}
static const char* categories[]={"All","NPC_","CREA"};
static const char* categoryLabels[]={"All","NPCs","Creatures"};
static void logLine(const char* text) {
 std::ofstream f(root+L"Data\\NVSE\\Plugins\\LukesActorBrowser.log",std::ios::app); f<<text<<"\n";
}
static void nativeStatus(const wchar_t* key,const wchar_t* value) {
 if(!bridgePath.empty())WritePrivateProfileStringW(L"Native",key,value,bridgePath.c_str());
}
static void failNative(const char* reason) {
 logLine(reason);std::wstring message;for(auto c:std::string(reason))message.push_back((unsigned char)c);
 nativeStatus(L"Error",message.c_str());
}
static void graphicsError(const char* operation,HRESULT hr) {
 static std::mutex errorMutex;std::lock_guard<std::mutex> guard(errorMutex);
 // Suppress identical per-frame failures without hiding changes in failure stage.
 static std::string last;static DWORD when=0;
 char message[192];sprintf_s(message,"%s failed (HRESULT 0x%08lX)",operation,(unsigned long)hr);
 DWORD now=GetTickCount();if(last==message && now-when<5000)return;
 last=message;when=now;failNative(message);
}
static std::wstring wide(const std::string& s) {
 if(s.empty()) return L""; int n=MultiByteToWideChar(CP_ACP,0,s.data(),(int)s.size(),nullptr,0);
 std::wstring r(n,0); MultiByteToWideChar(CP_ACP,0,s.data(),(int)s.size(),&r[0],n); return r;
}
static std::string narrow(const std::wstring& s) {
 int n=WideCharToMultiByte(CP_ACP,0,s.data(),(int)s.size(),nullptr,0,nullptr,nullptr);
 std::string r(n,0); if(n) WideCharToMultiByte(CP_ACP,0,s.data(),(int)s.size(),&r[0],n,nullptr,nullptr); return r;
}
static void filterItems() {
 dirty=true;lastClickItem=-1; visible.clear(); selected=-1; itemScroll=0;
 for(size_t i=0;i<catalog.items.size();++i) if((showTemplates||!ib::templateRecord(catalog.items[i])) && (showOverrides||!catalog.items[i].overrideRecord) && ib::matches(catalog.items[i],query,category?categories[category]:"")) visible.push_back(i);
 if(!visible.empty()) selected=0;
}
static void filterPlugins() {
 dirty=true;lastClickItem=-1; filteredPlugins.clear(); pluginScroll=0;
 for(size_t i=0;i<plugins.size();++i) if(ib::lower(narrow(plugins[i])).find(ib::lower(pluginQuery))!=std::string::npos) filteredPlugins.push_back((int)i);
}
static UINT bridgeNumber(const wchar_t* section,const wchar_t* key) {
 wchar_t value[80]{};GetPrivateProfileStringW(section,key,L"0",value,80,bridgePath.c_str());
 // JIP writes floats. Win32's integer reader truncates scientific notation.
 double number=wcstod(value,nullptr);if(!(number>=0&&number<=16777215))return 0;return (UINT)(number+0.5);
}
static double setting(const wchar_t* section,const wchar_t* key,double fallback,double lo,double hi) {
 wchar_t value[80]{};GetPrivateProfileStringW(section,key,L"",value,80,iniPath.c_str());
 wchar_t* end=nullptr;double n=wcstod(value,&end);
 if(end==value||*end||!std::isfinite(n))return fallback;
 return std::clamp(n,lo,hi);
}
static void scanPlugins() {
 plugins.clear(); livePlugins=false;
 if(!bridgePath.empty() && sessionToken && bridgeNumber(L"Bridge",L"Ready")==sessionToken) {
  int count=(int)bridgeNumber(L"Bridge",L"Count");
  if(count>0&&count<256) {for(int i=0;i<count;++i) {wchar_t name[512]{};GetPrivateProfileStringW(L"Loaded",std::to_wstring(i).c_str(),L"",name,512,bridgePath.c_str()); if(ib::pluginName(narrow(name)))plugins.emplace_back(name);}livePlugins=true;}
 }
 if(livePlugins) {std::sort(plugins.begin(),plugins.end(),[](auto& a,auto& b){return _wcsicmp(a.c_str(),b.c_str())<0;});filterPlugins();return;}
 WIN32_FIND_DATAW data;
 HANDLE h=FindFirstFileW((root+L"Data\\*").c_str(),&data);
 if(h!=INVALID_HANDLE_VALUE) {
  do {std::wstring n=data.cFileName; auto p=n.find_last_of(L'.'); if(p==n.npos || data.dwFileAttributes&FILE_ATTRIBUTE_DIRECTORY) continue;
   auto ext=ib::lower(narrow(n.substr(p))); if(ext==".esp"||ext==".esm") plugins.push_back(n);
  }while(FindNextFileW(h,&data)); FindClose(h);
 }
 std::sort(plugins.begin(),plugins.end(),[](auto& a,auto& b){return _wcsicmp(a.c_str(),b.c_str())<0;}); filterPlugins();
}
static void choosePlugin(int i) {
 if(loading || i<0 || i>=(int)plugins.size()) return;
 if(!ib::pluginName(narrow(plugins[i]))) {status="Invalid plugin filename rejected.";dirty=true;return;}
 pluginIndex=i; catalog={}; dirty=true;lastClickItem=-1; visible.clear(); selected=-1; itemScroll=0; loading=true;
 status="Reading plugin..."; auto path=root+L"Data\\"+plugins[i];
 try { std::thread([path] {
  try { auto c=ib::readPlugin(path,inflateFn); std::lock_guard<std::mutex> guard(catalogMutex); catalog=std::move(c); filterItems(); status=std::to_string(visible.size())+" matching actors. Record IDs are file-local, not console IDs."; }
  catch(const std::exception& e) {std::lock_guard<std::mutex> guard(catalogMutex); status=std::string("Could not read plugin: ")+e.what(); logLine(status.c_str());}
  {std::lock_guard<std::mutex> guard(catalogMutex);loading=false;dirty=true;}
 }).detach(); } catch(const std::exception&) {loading=false;status="Could not start plugin reader.";dirty=true;}
}
static void config() {
 float speed=(float)setting(L"Controls",L"MouseSpeed",1.6,.25,5);
 int opacity=(int)setting(L"Display",L"BackgroundOpacity",72,20,100);
 bool menu=setting(L"Audio",L"MenuSounds",1,0,1)>=.5,pickup=setting(L"Audio",L"PickupSounds",1,0,1)>=.5;
 bool overrides=setting(L"Browser",L"ShowOverrides",0,0,1)>=.5;bool templates=setting(L"Browser",L"ShowTemplates",0,0,1)>=.5;
 // FunctionKey is shared directly with the ESP-free MCM slider (F1-F24).
 // Older INIs using Windows virtual-key Hotkey values remain readable.
 const double legacyKey=setting(L"Controls",L"Hotkey",VK_F10,VK_F1,VK_F24);
 UINT key=VK_F1-1+(UINT)setting(L"Controls",L"FunctionKey",legacyKey-VK_F1+1,1,24);
 if(speed!=mouseSpeed||opacity!=backgroundOpacity||menu!=menuSounds||pickup!=pickupSounds||key!=hotkey)dirty=true;
 mouseSpeed=speed;backgroundOpacity=opacity;menuSounds=menu;pickupSounds=pickup;hotkey=key;
 if(overrides!=showOverrides||templates!=showTemplates){showOverrides=overrides;showTemplates=templates;filterItems();}
 if(!bridgePath.empty()) {
  static int reportedPickup=-1;static UINT reportedKey=0;
  if(reportedPickup!=(int)pickupSounds){nativeStatus(L"PickupSounds",pickupSounds?L"1":L"0");reportedPickup=(int)pickupSounds;}
  if(reportedKey!=hotkey){nativeStatus(L"Hotkey",(L"F"+std::to_wstring(hotkey-VK_F1+1)).c_str());reportedKey=hotkey;}
 }
}
static void requestItem() { dirty=true;
 if(loading||selected<0||selected>=(int)visible.size()||pluginIndex<0||pluginIndex>=(int)plugins.size())return;
 if(visible[selected]>=catalog.items.size())return;
 if(bridgeNumber(L"Bridge",L"Ready")!=sessionToken) {status="Actor bridge is not ready. Check the console for Luke's Actor Browser script errors.";logLine("Spawn request blocked: script bridge session is not ready.");return;}
 if(GetPrivateProfileIntW(L"Request",L"Pending",0,bridgePath.c_str())) {status="Waiting for the previous request to finish.";return;}
 const auto& item=catalog.items[visible[selected]]; if(!showTemplates&&ib::templateRecord(item))return; std::wstring origin=plugins[pluginIndex];
 if(item.overrideRecord){if((item.id>>24)>=catalog.masters.size())return;origin=wide(catalog.masters[item.id>>24]);}
 if(!ib::pluginName(narrow(origin))) {status="Invalid source filename rejected.";return;}
 quantity=std::clamp(quantity,1,5);
 wchar_t id[16];swprintf_s(id,L"%06X",item.id&0xFFFFFF);
 bool ok=WritePrivateProfileStringW(L"Request",L"Action",L"0",bridgePath.c_str())!=0;
 ok=ok && WritePrivateProfileStringW(L"Request",L"Plugin",origin.c_str(),bridgePath.c_str());
 ok=ok && WritePrivateProfileStringW(L"Request",L"Form",id,bridgePath.c_str());
 ok=ok && WritePrivateProfileStringW(L"Request",L"Count",std::to_wstring(quantity).c_str(),bridgePath.c_str());
 ok=ok && WritePrivateProfileStringW(L"Request",L"Session",std::to_wstring(sessionToken).c_str(),bridgePath.c_str());
 ok=ok && WritePrivateProfileStringW(L"Request",L"Result",L"Waiting for game...",bridgePath.c_str());
 ok=ok && WritePrivateProfileStringW(L"Request",L"Pending",L"1",bridgePath.c_str());
 status=ok?"Spawn request queued; the game will verify the form and spawn it.":"Could not write the spawn request INI.";
}
static bool inside(int x,int y,int w,int h) {return cursorX>=x && cursorX<x+w && cursorY>=y && cursorY<y+h;}
static void requestValue(int action) {
 dirty=true;
 if(bridgeNumber(L"Bridge",L"Ready")!=sessionToken){status="Load a save and check the actor script bridge.";return;}
 if(bridgeNumber(L"Request",L"Pending")){status="Waiting for the previous request.";return;}
 double value=0;
 if(action==2&&(!snapshotReady||!actorValueNumber(valueInput,value)||value<actorValues[avIndex].low||value>actorValues[avIndex].high)){
  status="Read the target first and enter a number within the displayed range.";return;
 }
 auto put=[](const wchar_t* key,const std::wstring& v){return WritePrivateProfileStringW(L"Request",key,v.c_str(),bridgePath.c_str())!=0;};
 bool ok=put(L"Action",std::to_wstring(action))&&put(L"Target",std::to_wstring(targetMode))&&put(L"AV",std::to_wstring(avIndex))
  &&put(L"Value",std::to_wstring(value))&&put(L"Session",std::to_wstring(sessionToken))&&put(L"Serial",std::to_wstring(++valueRequest))
  &&put(L"Result",L"")&&put(L"Pending",L"1");
 snapshotReady=false;status=ok?"Waiting for game...":"Could not write actor request.";
}
static void pollSnapshot() {
 if(bridgeNumber(L"Snapshot",L"Serial")!=valueRequest||bridgeNumber(L"Snapshot",L"Session")!=sessionToken)return;
 auto read=[](const wchar_t* key){wchar_t s[256]{};GetPrivateProfileStringW(L"Snapshot",key,L"--",s,256,bridgePath.c_str());return narrow(s);};
 targetName=read(L"Name");baseValue=read(L"Base");currentValue=read(L"Current");
 snapshotReady=bridgeNumber(L"Snapshot",L"Valid")==1&&bridgeNumber(L"Snapshot",L"AV")==unsigned(avIndex)&&bridgeNumber(L"Snapshot",L"Target")==unsigned(targetMode);
}
static void fill(int x,int y,int w,int h,COLORREF color) { if(nativeDrawing){nativeui::rect(x,y,w,h,color);return;} RECT r{x,y,x+w,y+h}; auto b=CreateSolidBrush(color); FillRect(canvas,&r,b); DeleteObject(b); }
static void text(int x,int y,int w,int h,const std::wstring& t,COLORREF color=RGB(235,182,86),int f=0,bool centered=false) {
 if(nativeDrawing){nativeui::text(x,y,w,h,color,f==titleFont?32:f==smallFont?17:f==detailFont?27:22,f==titleFont||f==capsFont,centered,narrow(t));return;}
 GdiFlush();
 const auto& face=(f==titleFont||f==capsFont)?vanillaHeading:(f==detailFont||f==glowFont)?vanillaGlow:vanillaBody;
 int size=f==titleFont?32:f==smallFont?17:f==detailFont?27:22;
 face.draw((uint32_t*)pixels,rasterWidth(),rasterHeight(),x*renderScale,y*renderScale,w*renderScale,h*renderScale,narrow(t),size*renderScale,color,centered,f==titleFont?0.8f*renderScale:0.f);
}
static void label(int x,int y,int w,int h,const std::string& t,COLORREF color=RGB(235,182,86),int f=0,bool centered=false) {text(x,y,w,h,wide(t),color,f,centered);}
static void border(int x,int y,int w,int h,COLORREF c=RGB(121,92,45)) {fill(x,y,w,1,c);fill(x,y+h-1,w,1,c);fill(x,y,1,h,c);fill(x+w-1,y,1,h,c);}
static void button(int x,int y,int w,int h,const std::string& t,bool active=false,int face=glowFont) {
 if(active)fill(x,y,w,h,RGB(57,44,22));border(x,y,w,h,active?RGB(246,185,77):RGB(129,96,43));label(x+8,y,w-16,h,t,RGB(235,182,86),face,true);
}
static void tab(int x,int y,int w,const std::string& t,bool active) {
 if(active)button(x,y,w,30,t,true,capsFont);else label(x+8,y,w-16,30,t,RGB(170,128,61),capsFont,true);
}
static int scrollThumb(int count) {return count<=ListRows?ListHeight:std::max(24,ListHeight*ListRows/count);}
static int scrollY(int scroll,int count) {return ListTop+(count>ListRows?(ListHeight-scrollThumb(count))*scroll/(count-ListRows):0);}
static void scrollbar(int x,int scroll,int count) {
 fill(x+3,ListTop,1,ListHeight,RGB(120,90,41));if(count>ListRows)fill(x+1,scrollY(scroll,count),5,scrollThumb(count),RGB(247,185,76));
}
static void shortcut(int x,int w,const std::string& key,const std::string& title) {
 border(x,623,w,31);label(x+5,623,w-10,31,key,RGB(235,182,86),smallFont,true);label(x+w+8,623,135,31,title);
}
// Shared category geometry keeps visible tabs and mouse targets aligned.
static const int categoryWidths[]={60,85,110};
static int categoryX(int index) {int x=27;for(int n=0;n<index;++n)x+=categoryWidths[n]+5;return x;}
static void panel(int x,int w,const char* title) {
 border(x,153,w,449,RGB(103,78,39));
 fill(x+1,154,w-2,31,RGB(35,31,22));
 label(x+10,154,w-20,30,title,RGB(248,188,79),capsFont);
 fill(x+1,185,w-2,1,RGB(173,126,48));
}
static void buildBackdrop() {
 if(backdropScale==renderScale&&!backdrop.empty())return;
 ++backdropBuilds;
 // Soft phosphor bands with irregular luminance, not a repeating square grid.
 fill(0,0,Width,Height,RGB(0,0,0));
 fill(10,10,Width-24,Height-24,RGB(9,10,9));
 GdiFlush();auto backgroundPixels=(uint32_t*)pixels;
 auto noise=[](int x,int y) {
  uint32_t h=(uint32_t)x*374761393u+(uint32_t)y*668265263u;
  h=(h^(h>>13))*1274126177u;h^=h>>16;
  return (h&65535)/65535.f;
 };
 for(int py=12*renderScale;py<(Height-16)*renderScale;++py) {
  float y=py/(float)renderScale;
  float wave=0.5f+0.5f*std::cos(y*6.2831853f/6.2f);
  float band=wave*wave;
  int ny=(int)(y/8.f);float fy=y/8.f-ny;fy=fy*fy*(3.f-2.f*fy);
  for(int px=12*renderScale;px<(Width-16)*renderScale;++px) {
   float x=px/(float)renderScale;
   int nx=(int)(x/5.f);float fx=x/5.f-nx;fx=fx*fx*(3.f-2.f*fx);
   float a=noise(nx,ny)*(1-fx)+noise(nx+1,ny)*fx;
   float b=noise(nx,ny+1)*(1-fx)+noise(nx+1,ny+1)*fx;
   float mottle=a*(1-fy)+b*fy;
   float edge=std::clamp(std::min({x-12.f,Width-16.f-x,y-12.f,Height-16.f-y})/26.f,0.f,1.f);
   float vignette=0.78f+0.22f*std::max(0.f,1.f-std::abs(x-Width*.5f)/(Width*.5f));
   float luminance=5.f+edge*vignette*(3.f+band*(9.f+17.f*mottle)+2.f*mottle);
   unsigned shade=(unsigned)std::clamp(luminance,0.f,255.f);
   backgroundPixels[py*rasterWidth()+px]=(shade<<16)|(shade<<8)|shade;
  }
 }
 backdrop.assign(backgroundPixels,backgroundPixels+(size_t)rasterWidth()*rasterHeight());backdropScale=renderScale;
}
static void drawLists(unsigned mask) {
 for(int row=0;row<ListRows;++row) {
  int p=pluginScroll+row,y=ListTop+row*RowHeight;
  if((mask&1)&&p<(int)filteredPlugins.size()) {int idx=filteredPlugins[p];if(idx==pluginIndex){fill(27,y,310,28,RGB(57,44,22));border(27,y,310,28,RGB(241,183,80));}text(37,y,290,28,plugins[idx]);}
  int item=itemScroll+row;
  if((mask&2)&&item<(int)visible.size()) {const auto& entry=catalog.items[visible[item]];if(item==selected){fill(369,y,313,28,RGB(57,44,22));border(369,y,313,28,RGB(241,183,80));}label(379,y,293,28,entry.name);}
 }
 if(mask&1)scrollbar(340,pluginScroll,(int)filteredPlugins.size());
 if(mask&2){scrollbar(686,itemScroll,(int)visible.size());if(loading)label(379,244,295,30,"Reading plugin...");else if(pluginIndex>=0&&visible.empty())label(379,244,295,30,"No matching actors.");}
}
static void applyAlpha(int left,int top,int right,int bottom) {
 GdiFlush();auto p=(uint32_t*)pixels;unsigned lut[256];const unsigned base=backgroundOpacity*255/100;
 for(unsigned i=0;i<256;++i)lut[i]=(base+(255-base)*std::min(i,180u)/180)<<24;
 for(int y=top;y<bottom;++y)for(int x=left;x<right;++x){
  size_t i=(size_t)y*rasterWidth()+x;uint32_t c=p[i];
  if(x>=7*renderScale&&x<(Width-13)*renderScale&&y>=7*renderScale&&y<(Height-13)*renderScale){
   unsigned b=std::max({c&255,(c>>8)&255,(c>>16)&255});p[i]=tintPixel(b)|lut[b];
  }else {
   float lx=x/(float)renderScale,ly=y/(float)renderScale;
   float dx=std::max({13.f-lx,0.f,lx-(Width-13.f)}),dy=std::max({13.f-ly,0.f,ly-(Height-13.f)});
   p[i]=(unsigned)(115.f*std::max(0.f,1.f-std::max(dx,dy)/12.f))<<24;
  }
 }
}
static void redrawLists(unsigned mask) {
 ++listBuilds;GdiFlush();auto p=(uint32_t*)pixels;
 for(unsigned bit:{1u,2u})if(mask&bit){
  int left=(bit==1?27:365)*renderScale,right=(bit==1?353:702)*renderScale;
  int top=ListTop*renderScale,bottom=(ListTop+ListHeight)*renderScale;
  for(int y=top;y<bottom;++y){size_t offset=(size_t)y*rasterWidth()+left;memcpy(p+offset,backdrop.data()+offset,(right-left)*sizeof(uint32_t));}
  drawLists(bit);applyAlpha(left,top,right,bottom);
 }
}
static void drawCanvas() {
 ++canvasBuilds;if(nativeDrawing)nativeui::begin();else{buildBackdrop();GdiFlush();memcpy(pixels,backdrop.data(),backdrop.size()*sizeof(uint32_t));}
 // Inset amber frame leaves transparent room for a real external drop shadow.
 border(7,7,Width-20,Height-20,RGB(65,45,16));
 border(8,8,Width-22,Height-22,RGB(143,96,29));
 border(9,9,Width-24,Height-24,RGB(255,189,66));
 border(10,10,Width-26,Height-26,RGB(230,161,47));
 border(11,11,Width-28,Height-28,RGB(88,62,24));
 label(28,20,650,50,"ACTOR BROWSER",RGB(250,194,90),titleFont);
 tab(710,27,135,"VALUES",valuesPage);tab(858,27,108,"SPAWN",!settingsPage&&!valuesPage);tab(978,27,110,"SETTINGS",settingsPage);
 fill(26,144,1067,1,RGB(163,117,45));
 if(valuesPage&&!settingsPage) {
  label(28,94,700,32,"ACTOR VALUES",RGB(250,194,90),capsFont);
  panel(26,328,"TARGET");panel(364,339,"ACTOR VALUE");panel(713,378,"VALUE DETAILS");
  button(40,205,296,36,"PLAYER",targetMode==0);
  button(40,255,296,36,"CROSSHAIR ACTOR",targetMode==1);
  button(40,305,296,36,"LAST SPAWNED",targetMode==2);
  button(40,369,296,36,"READ / CAPTURE TARGET");
  label(40,425,288,30,targetName,RGB(250,194,90));
  label(40,471,288,25,"Aim before capturing.",RGB(183,155,103),smallFont);
  label(40,502,288,25,"Captured target is retained.",RGB(183,155,103),smallFont);
  for(int row=0;row<ListRows&&avScroll+row<ActorValueCount;++row){int idx=avScroll+row,y=ListTop+row*RowHeight;button(369,y,313,28,actorValues[idx].label,idx==avIndex);}
  scrollbar(686,avScroll,ActorValueCount);
  label(727,199,350,44,actorValues[avIndex].label,RGB(250,194,90),detailFont);
  label(727,265,350,30,"BASE: "+baseValue);
  label(727,305,350,30,"CURRENT: "+currentValue);
  label(727,353,350,25,"NEW BASE VALUE",RGB(183,155,103),smallFont);
  button(727,390,350,40,valueInput,focus==3);
  label(727,442,350,25,"Range: "+std::to_string((int)actorValues[avIndex].low)+" to "+std::to_string((int)actorValues[avIndex].high),RGB(183,155,103),smallFont);
  button(727,491,350,38,"APPLY VALUE",snapshotReady);
  label(727,547,350,25,"Effects and scripts may alter values.",RGB(183,155,103),smallFont);
 } else
 if(settingsPage) {
  label(32,150,600,36,"DISPLAY AND CONTROLS",RGB(250,194,90),capsFont);
  label(32,210,470,32,"MOUSE SPEED");button(510,210,75,32,"-",false);button(598,210,135,32,std::to_string((int)(mouseSpeed*100))+"%",true);button(746,210,75,32,"+");
  label(32,267,470,32,"BACKGROUND OPACITY");button(510,267,75,32,"-");button(598,267,135,32,std::to_string(backgroundOpacity)+"%",true);button(746,267,75,32,"+");
  label(32,324,470,32,"MENU OPEN / CLOSE SOUNDS");button(510,324,180,32,menuSounds?"ON":"OFF",menuSounds);
  label(32,381,470,32,"SHOW TEMPLATES");button(510,381,180,32,showTemplates?"ON":"OFF",showTemplates);
  label(32,438,470,32,"INCLUDE OVERRIDE RECORDS");button(510,438,180,32,showOverrides?"ON":"OFF",showOverrides);
  label(32,510,980,30,"Settings save to LukesActorBrowser.ini. Hotkey and native font slots can also be edited there.",RGB(183,155,103),smallFont);
  button(32,563,190,32,"REFRESH LIST");button(242,563,190,32,"CLEAR SEARCH");
 } else {
  for(int i=0;i<3;++i) {std::string t=categoryLabels[i];for(auto& c:t)c=(char)toupper(c);int x=categoryX(i),w=categoryWidths[i];if(category==i){fill(x,104,w,30,RGB(57,44,22));border(x,104,w,30,RGB(246,185,77));}label(x+6,104,w-12,30,t,category==i?RGB(250,194,90):RGB(190,147,73),smallFont,true);}
  label(788,72,62,26,"SEARCH",RGB(174,135,70),smallFont);
  button(855,72,99,26,"ACTORS",searchScope==2);button(961,72,128,26,"PLUGINS",searchScope==1);
  const auto& searchText=searchScope==1?pluginQuery:query;
  button(788,104,301,31,searchText.empty()?(searchScope==1?"Search plugins...":"Search actors..."):searchText,focus!=0);
  panel(26,328,"PLUGINS");panel(364,339,"ACTORS");panel(713,378,"ACTOR DETAILS");
  drawLists(3);
  if(selected>=0&&selected<(int)visible.size()) {
   const auto& i=catalog.items[visible[selected]];char id[16];sprintf_s(id,"%08X",i.id);
   std::string name=i.name;for(auto& c:name)c=(char)toupper((unsigned char)c);label(726,198,350,44,name,RGB(250,194,90),detailFont);
   // Record metadata is real; no fake per-item weapon model is shown.
   label(727,263,350,30,"TYPE");label(727,295,350,30,i.type=="NPC_"?"NPC":"Creature");
   label(727,348,350,28,"PLUGIN",RGB(171,132,67));
   if(i.overrideRecord&&(i.id>>24)<catalog.masters.size())label(727,375,350,30,catalog.masters[i.id>>24]);else text(727,375,350,30,plugins[pluginIndex]);
   label(727,421,350,28,"EDITOR ID",RGB(171,132,67));label(727,448,350,30,i.editor.empty()?"(none)":i.editor);
   label(727,490,350,25,std::string("LOCAL ID: ")+id,RGB(180,143,80),smallFont);
   fill(725,535,358,1,RGB(137,102,45));label(727,551,103,32,"Spawn:");
   const int counts[]={1,3,5};for(int n=0;n<3;++n)button(834+n*84,551,72,32,std::to_string(counts[n]),quantity==counts[n]);
  }
  label(28,601,560,22,std::to_string(visible.size())+" ACTORS  /  "+std::to_string(filteredPlugins.size())+(livePlugins?" LOADED PLUGINS":" INSTALLED PLUGINS"),RGB(170,132,70),smallFont);
 }
 if(controllerPrompts){
  label(28,624,1060,29,valuesPage?"A Select   X Apply   B Back   LB/RB Column   LT/RT Page   START Tabs   Y Type":"A Select   X Spawn   B Back   LB/RB Column   LT/RT Page   START Tabs   Y Search",RGB(235,182,86),smallFont);
 }else{
  if(!settingsPage &&!valuesPage)shortcut(609,60,"ENTER","SPAWN");shortcut(810,45,"F"+std::to_string(hotkey-VK_F1+1),"CLOSE");shortcut(973,45,"ESC","BACK");
  label(28,624,560,29,focus?"Type using the PC keyboard":"Double-click a record to spawn",RGB(173,139,84),smallFont);
 }
 label(28,658,790,25,status,RGB(200,162,103),smallFont);
 label(846,658,244,25,"v1.0.12-native3  |  luke2172",RGB(173,139,84),smallFont,true);
 drawControllerFocus();
 if(!nativeDrawing)applyAlpha(0,0,rasterWidth(),rasterHeight());
}
static void menuSound(int event) {if(menuSounds&&!bridgePath.empty())WritePrivateProfileStringW(L"Audio",L"Menu",std::to_wstring(event).c_str(),bridgePath.c_str());}
static void closeBrowser() {opened=false;blockUntil=GetTickCount()+250;focus=0;dragScroll=0;lastClickItem=-1;menuSound(2);}
static void savePreferences() {
 WritePrivateProfileStringW(L"Browser",L"ShowTemplates",showTemplates?L"1":L"0",iniPath.c_str());
 WritePrivateProfileStringW(L"Browser",L"ShowOverrides",showOverrides?L"1":L"0",iniPath.c_str());
 WritePrivateProfileStringW(L"Controls",L"MouseSpeed",std::to_wstring(mouseSpeed).c_str(),iniPath.c_str());
 WritePrivateProfileStringW(L"Display",L"BackgroundOpacity",std::to_wstring(backgroundOpacity).c_str(),iniPath.c_str());
 WritePrivateProfileStringW(L"Audio",L"MenuSounds",menuSounds?L"1":L"0",iniPath.c_str());
 WritePrivateProfileStringW(L"Audio",L"PickupSounds",pickupSounds?L"1":L"0",iniPath.c_str());nativeStatus(L"PickupSounds",pickupSounds?L"1":L"0");
}
static void dragScrollbar() {
 if(dragScroll==3){int travel=ListHeight-scrollThumb(ActorValueCount);int next=std::clamp((int)((cursorY-ListTop-dragOffset)*(ActorValueCount-ListRows)/travel+.5f),0,ActorValueCount-ListRows);if(next!=avScroll){avScroll=next;dirty=true;}return;}
 int count=dragScroll==1?(int)filteredPlugins.size():(int)visible.size();auto& scroll=dragScroll==1?pluginScroll:itemScroll;
 int before=scroll;int travel=ListHeight-scrollThumb(count);if(travel>0)scroll=std::clamp((int)((cursorY-ListTop-dragOffset)*(count-ListRows)/travel+0.5f),0,count-ListRows);
 if(scroll!=before){listDirty|=dragScroll==1?1:2;lastClickItem=-1;}
}
static void click() {
 dirty=true;
 if(inside(710,27,135,30)){valuesPage=true;settingsPage=false;focus=0;snapshotReady=false;requestValue(1);return;}
 if(inside(858,27,108,30)){valuesPage=false;settingsPage=false;lastClickItem=-1;return;}
 if(inside(978,27,110,30)){valuesPage=false;settingsPage=true;focus=0;lastClickItem=-1;return;}
 if(inside(810,623,148,31)){closeBrowser();return;} if(inside(973,623,123,31)){if(settingsPage){settingsPage=false;return;}closeBrowser();return;}
 if(settingsPage) {
  if(inside(510,210,75,32))mouseSpeed=std::max(.25f,mouseSpeed-.25f);
  if(inside(746,210,75,32))mouseSpeed=std::min(5.f,mouseSpeed+.25f);
  if(inside(510,267,75,32))backgroundOpacity=std::max(20,backgroundOpacity-5);
  if(inside(746,267,75,32))backgroundOpacity=std::min(100,backgroundOpacity+5);
  if(inside(510,324,180,32))menuSounds=!menuSounds;
  
  if(inside(510,381,180,32)){showTemplates=!showTemplates;filterItems();}
  if(inside(510,438,180,32)){showOverrides=!showOverrides;filterItems();}
  if(inside(32,563,190,32)&&!loading){scanPlugins();pluginIndex=-1;catalog={};filterItems();status="Plugin list refreshed.";}
  if(inside(242,563,190,32)){query.clear();pluginQuery.clear();filterPlugins();filterItems();}
  savePreferences();return;
 }
 if(valuesPage) {
  focus=0;
  if(inside(684,ListTop,12,ListHeight)){dragScroll=3;int top=scrollY(avScroll,ActorValueCount),thumb=scrollThumb(ActorValueCount);dragOffset=cursorY>=top&&cursorY<top+thumb?cursorY-top:thumb/2.f;dragScrollbar();return;}
  for(int t=0;t<3;++t)if(inside(40,205+t*50,296,36)){targetMode=t;snapshotReady=false;requestValue(t==1?3:1);return;}
  if(inside(40,369,296,36)){requestValue(targetMode==1?3:1);return;}
  if(inside(369,ListTop,313,ListHeight)){int n=avScroll+((int)cursorY-ListTop)/RowHeight;if(n<ActorValueCount){avIndex=n;snapshotReady=false;requestValue(1);}return;}
  if(inside(727,390,350,40)){focus=3;return;}
  if(inside(727,491,350,38)){requestValue(2);return;}
  return;
 }
 bool itemClick=inside(369,ListTop,313,ListHeight);if(!itemClick)lastClickItem=-1;
 for(int i=0;i<3;++i)if(inside(categoryX(i),104,categoryWidths[i],30)){category=i;filterItems();focus=0;return;}
 if(inside(855,72,99,26)){focus=searchScope=2;return;}if(inside(961,72,128,26)){focus=searchScope=1;return;}
 if(inside(788,104,301,31)){focus=searchScope;return;}focus=0;
 const int counts[]={1,3,5};for(int n=0;n<3;++n)if(inside(834+n*84,551,72,32)){quantity=counts[n];return;}
 if(inside(609,623,185,31)){requestItem();return;}
 for(int n=1;n<=2;++n)if(inside(n==1?338:684,ListTop,12,ListHeight)) {
  dragScroll=n;int scroll=n==1?pluginScroll:itemScroll,count=n==1?(int)filteredPlugins.size():(int)visible.size();
  int top=scrollY(scroll,count),thumb=scrollThumb(count);dragOffset=cursorY>=top&&cursorY<top+thumb?cursorY-top:thumb/2.f;dragScrollbar();lastClickItem=-1;return;
 }
 if(inside(27,ListTop,310,ListHeight)){int p=pluginScroll+((int)cursorY-ListTop)/RowHeight;if(p<(int)filteredPlugins.size())choosePlugin(filteredPlugins[p]);return;}
 if(itemClick&&!loading) {
  int p=itemScroll+((int)cursorY-ListTop)/RowHeight;if(p>=(int)visible.size()){lastClickItem=-1;return;}
  selected=p;DWORD now=GetTickCount();
  if(lastClickItem==p&&now-lastClickTime<=GetDoubleClickTime()&&abs(cursorX-lastClickX)<6&&abs(cursorY-lastClickY)<6){lastClickItem=-1;requestItem();}
  else {lastClickItem=p;lastClickTime=now;lastClickX=cursorX;lastClickY=cursorY;}
 }
}
static void scrollWheel(long delta) {
 if(valuesPage){if(inside(369,ListTop,329,ListHeight)){static long avRemainder=0;avRemainder+=std::clamp(delta,-12000L,12000L);int steps=avRemainder/120;avRemainder%=120;int next=std::clamp(avScroll-steps*3,0,ActorValueCount-ListRows);if(next!=avScroll){avScroll=next;dirty=true;}}return;}
 static long remainder=0;static unsigned previousTarget=0;
 unsigned target=settingsPage?0:inside(27,ListTop,323,ListHeight)?1:inside(369,ListTop,329,ListHeight)?2:0;
 if(target!=previousTarget){remainder=0;previousTarget=target;}
 if(!target)return;
 long total=remainder+std::clamp(delta,-12000L,12000L);int steps=(int)(total/WHEEL_DELTA);remainder=total%WHEEL_DELTA;
 auto& offset=target==1?pluginScroll:itemScroll;int count=(int)(target==1?filteredPlugins.size():visible.size());
 int next=std::clamp(offset-steps*3,0,std::max(0,count-ListRows));
 if(next!=offset){offset=next;listDirty|=target;lastClickItem=-1;}
}
static void setPromptMode(bool controller){if(controllerPrompts!=controller){controllerPrompts=controller;dirty=true;}}
#include "navigation.h"
static void inputs() {
 static DWORD lastConfigPoll=0;
 if(GetTickCount()-lastConfigPoll>=1000){lastConfigPoll=GetTickCount();config();
  if(bridgeNumber(L"Theme",L"Session")==sessionToken&&sessionToken){
   unsigned r=bridgeNumber(L"Theme",L"Red"),g=bridgeNumber(L"Theme",L"Green"),b=bridgeNumber(L"Theme",L"Blue");
   if(r<=255&&g<=255&&b<=255){uint32_t next=(r<<16)|(g<<8)|b;if(next!=themeRGB){themeRGB=next;dirty=true;}}
  }
  const WORD directions[]={XINPUT_GAMEPAD_DPAD_LEFT,XINPUT_GAMEPAD_DPAD_RIGHT,XINPUT_GAMEPAD_DPAD_UP,XINPUT_GAMEPAD_DPAD_DOWN};
  controllerOpenButton=directions[(int)setting(L"Controls",L"ControllerOpenDirection",2,1,4)-1];}
 DWORD process=0; GetWindowThreadProcessId(GetForegroundWindow(),&process);
 if(process!=GetCurrentProcessId()) {if(opened)closeBrowser();return;}
 auto controllerEvent=controllerDecoder.update(pad::sample(),GetTickCount(),controllerOpenButton);
 bool pressed[256]{};
 if(opened||!monitorActive)for(int k=0;k<256;++k) {bool down=(GetAsyncKeyState(k)&0x8000)!=0;pressed[k]=down&&!previousKeys[k];previousKeys[k]=down;}
 bool queued=consumeToggle(GetTickCount());
 if(controllerEvent.chord||queued||(!monitorActive&&pressed[hotkey])) {if(opened) closeBrowser();else {if(!controlsReady||gameMenuActive()||!acquireBrowser())return;
if(!controlLease.acquire()){if(!controlLease.active())releaseBrowser();logLine("Could not acquire supported player controls. Menu opening cancelled.");return;}
controllerPrompts=controllerEvent.chord;logLine("Opening browser.");config();if(!loading){scanPlugins();pluginIndex=-1;catalog={};filterItems();}opened=true;dirty=true;settingsPage=false;valuesPage=false;snapshotReady=false;lastClickItem=-1;menuSound(1);cursorX=controllerPrompts?180.f:560.f;cursorY=controllerPrompts?204.f:350.f;mouseDX=0;mouseDY=0;wheelDelta=0;}return;}
 if(!opened)return;
 bool keyboardActivity=false;for(int k=1;k<256;++k)if(pressed[k])keyboardActivity=true;
 if((keyboardActivity||mouseDX.load()!=0||mouseDY.load()!=0||wheelDelta.load()!=0)&&controllerPrompts)setPromptMode(false);
 controllerActions(controllerEvent);if(!opened)return;
 if(pressed[VK_ESCAPE]) {if(settingsPage){settingsPage=false;dirty=true;}else closeBrowser();return;}
 cursorX=std::clamp(cursorX+mouseDX.exchange(0)*mouseSpeed,0.f,(float)Width-1); cursorY=std::clamp(cursorY+mouseDY.exchange(0)*mouseSpeed,0.f,(float)Height-1);
 if(pressed[VK_LBUTTON])click();if(!previousKeys[VK_LBUTTON])dragScroll=0;else if(dragScroll)dragScrollbar();
 auto wheel=wheelDelta.exchange(0);if(wheel)scrollWheel(wheel);
 if(pressed[VK_TAB]&&!settingsPage&&!valuesPage){searchScope=searchScope==1?2:1;focus=searchScope;dirty=true;}
 if(pressed[VK_RETURN]&&!focus&&!settingsPage&&!valuesPage)requestItem();
 static DWORD lastStatusPoll=0;
 if(GetTickCount()-lastStatusPoll>500) {
  lastStatusPoll=GetTickCount();if(valuesPage)pollSnapshot();wchar_t result[512]{};GetPrivateProfileStringW(L"Request",L"Result",L"",result,512,bridgePath.c_str());
  if(result[0] && !GetPrivateProfileIntW(L"Request",L"Pending",0,bridgePath.c_str())) {dirty=true;status=narrow(result);WritePrivateProfileStringW(L"Request",L"Result",L"",bridgePath.c_str());}
 }
 if(focus && !loading) {
  auto& target=focus==3?valueInput:focus==1?pluginQuery:query; bool changed=false;
  if(pressed[VK_BACK]&&!target.empty()) {target.pop_back();changed=true;}
  BYTE keyboard[256]{}; GetKeyboardState(keyboard); keyboard[VK_SHIFT]=previousKeys[VK_SHIFT]?0x80:0; keyboard[VK_CONTROL]=0;keyboard[VK_MENU]=0;
  for(UINT k=0x20;k<=0xFE;++k) if(pressed[k] && k!=hotkey && !(k>=VK_F1&&k<=VK_F24) && k!=VK_DELETE) {
   wchar_t chars[8]{}; int n=ToUnicode(k,MapVirtualKeyW(k,MAPVK_VK_TO_VSC),keyboard,chars,8,0);
   if(n>0 && chars[0]>=32 && target.size()<(focus==3?12u:120u) && (focus!=3||(chars[0]>=48&&chars[0]<=57)||chars[0]==46||chars[0]==45)) {auto s=narrow(std::wstring(chars,n)); target+=s;changed=true;}
  }
  if(changed) {dirty=true;if(focus==1)filterPlugins();else if(focus==2)filterItems();}
 }
}
using StateFn=HRESULT (STDMETHODCALLTYPE*)(IDirectInputDevice8W*,DWORD,LPVOID);
using DataFn=HRESULT (STDMETHODCALLTYPE*)(IDirectInputDevice8W*,DWORD,LPDIDEVICEOBJECTDATA,LPDWORD,DWORD);
static StateFn originalState;
static DataFn originalData;
static bool blockInput() {
 DWORD pid=0;GetWindowThreadProcessId(GetForegroundWindow(),&pid);
 if(pid!=GetCurrentProcessId())return false;
 // Never hold game input indefinitely when a wrapper stops calling the renderer.
 if(monitorActive&&GetTickCount()-lastFrameTick.load()>1500)return false;
 return opened || (LONG)(blockUntil.load()-GetTickCount())>0;
}
static HRESULT STDMETHODCALLTYPE stateHook(IDirectInputDevice8W* dev,DWORD size,LPVOID data) {
 auto next=hookRegistry.next<StateFn>(dev,9);if(!next)return DIERR_GENERIC;auto hr=next(dev,size,data); if(SUCCEEDED(hr)&&data&&blockInput()) {
  if(opened && (size==sizeof(DIMOUSESTATE)||size==sizeof(DIMOUSESTATE2))) {auto m=(DIMOUSESTATE*)data;mouseDX+=m->lX;mouseDY+=m->lY;wheelDelta+=m->lZ;}
  memset(data,0,size);
 } return hr;
}
static HRESULT STDMETHODCALLTYPE dataHook(IDirectInputDevice8W* dev,DWORD size,LPDIDEVICEOBJECTDATA data,LPDWORD count,DWORD flags) {
 auto next=hookRegistry.next<DataFn>(dev,10);if(!next)return DIERR_GENERIC;auto hr=next(dev,size,data,count,flags); if(SUCCEEDED(hr)&&blockInput()&&count) *count=0; return hr;
}
static bool replaceSlot(void** table,int slot,void* hook,void** original) {return hookRegistry.install(table,slot,hook,original);}
using InputFactoryFn=HRESULT (WINAPI*)(HINSTANCE,DWORD,REFIID,LPVOID*,LPUNKNOWN);
using InputDeviceFn=HRESULT (STDMETHODCALLTYPE*)(IDirectInput8W*,REFGUID,IDirectInputDevice8W**,LPUNKNOWN);
static InputFactoryFn originalInputFactory;
static InputDeviceFn originalInputDevice;
static HRESULT STDMETHODCALLTYPE inputDeviceHook(IDirectInput8W* self,REFGUID guid,IDirectInputDevice8W** out,LPUNKNOWN outer) {
 auto next=hookRegistry.next<InputDeviceFn>(self,3);if(!next)return DIERR_GENERIC;auto hr=next(self,guid,out,outer);
 if(SUCCEEDED(hr)&&out&&*out&&(guid==GUID_SysMouse||guid==GUID_SysKeyboard)) {
  auto table=*(void***)*out;
  if(replaceSlot(table,9,(void*)stateHook,(void**)&originalState)&&replaceSlot(table,10,(void*)dataHook,(void**)&originalData)) {
   inputReady=true;nativeStatus(L"Input",L"1");logLine(guid==GUID_SysMouse?"Captured game mouse input.":"Captured game keyboard input.");
  }else failNative("Could not attach game input hooks");
 }return hr;
}
static HRESULT WINAPI inputFactoryHook(HINSTANCE instance,DWORD version,REFIID iid,LPVOID* out,LPUNKNOWN outer) {
 auto hr=originalInputFactory(instance,version,iid,out,outer);
 if(SUCCEEDED(hr)&&out&&*out)replaceSlot(*(void***)*out,3,(void*)inputDeviceHook,(void**)&originalInputDevice);return hr;
}

static nativeui::View nativeView;
static void* nativeInjectScript=nullptr;
static DWORD nativeRetryAt=0;
static unsigned nativeAttempts=0;
static const char* nativeRootName="LukesActorNative";
static bool nativeReady(){
 if(!GetModuleHandleW(L"ui_organizer.dll")){
  static bool reported=false;if(!reported){failNative("Native font scaling requires UIO - User Interface Organizer 2.20 or newer.");reported=true;}return false;
 }
 auto hud=nativeui::hud();if(!hud)return false;
 auto tile=nativeui::child(hud,nativeRootName);
 if(!tile&&nativeAttempts<3&&(LONG)(GetTickCount()-nativeRetryAt)>=0){
  ++nativeAttempts;nativeRetryAt=GetTickCount()+3000;
  if(!nativeInjectScript)nativeInjectScript=controlScripts->compileExpression("InjectUIXML \"HUDMainMenu\" \"data\\menus\\prefabs\\LukesActorBrowser\\Native.xml\"");
  BrowserScriptResult r{};
  if(!nativeInjectScript||!controlScripts->call(nativeInjectScript,nullptr,nullptr,&r,0)||r.type!=1||r.number!=1){
   failNative("Native XML injection failed. Check packaged menus/prefabs files and the console.");return false;
  }
  tile=nativeui::child(hud,nativeRootName);
 }
 if(!tile){nativeView.forget();return false;}
 auto previous=nativeView.root;
 if(!nativeView.bind(tile)){failNative("Native XML tile pool is incomplete.");return false;}
 if(previous!=nativeView.root){dirty=true;nativeView.hide();logLine("Native game UI tiles ready; no Direct3D hooks installed.");}
 if(previous!=nativeView.root)nativeView.bodyFont=(int)setting(L"NativeUI",L"BodyFont",3,1,8);
 if(previous!=nativeView.root)nativeView.headingFont=(int)setting(L"NativeUI",L"HeadingFont",2,1,8);
 if(previous!=nativeView.root){nativeView.bodyBaseline=(float)setting(L"NativeUI",L"BodyBaseline",0.25,-0.5,0.5);nativeView.headingBaseline=(float)setting(L"NativeUI",L"HeadingBaseline",0.33,-0.5,0.5);}
 auto oldScale=nativeView.scale;if(!nativeView.layout())return false;if(oldScale!=nativeView.scale)dirty=true;
 lastFrameTick=GetTickCount();if(!frameSeen.exchange(true)){nativeStatus(L"Frames",L"1");nativeStatus(L"Error",L"");}
 return true;
}
static void nativePaint(){
 if(!opened){nativeView.hide();return;}
 // Rebuild only after state changes; the engine draws retained tiles each frame.
 if(dirty||listDirty){
  drawCanvas();
  if(!nativeView.paint(themeRGB,backgroundOpacity)){failNative("Native UI layout unavailable or tile pool exceeded.");closeBrowser();nativeView.hide();return;}
  dirty=false;listDirty=0;
 }
 nativeView.pointer(cursorX,cursorY,controllerPrompts,themeRGB);
}


static DWORD WINAPI hotkeyMonitor(void*) {
 bool wasDown=false;UINT key=VK_F10;DWORD poll=0;
 for(;;) {
  DWORD now=GetTickCount();
  if(now-poll>=1000){poll=now;double old=setting(L"Controls",L"Hotkey",VK_F10,VK_F1,VK_F24);key=VK_F1-1+(UINT)setting(L"Controls",L"FunctionKey",old-VK_F1+1,1,24);}
  DWORD pid=0;GetWindowThreadProcessId(GetForegroundWindow(),&pid);
  bool down=(GetAsyncKeyState(key)&0x8000)!=0;
  if(pid==GetCurrentProcessId()&&down&&!wasDown) {
   logLine("Hotkey monitor detected key press.");
   if(!lastFrameTick||now-lastFrameTick.load()>1500)failNative("Hotkey received but native UI is not ready. Check XML injection and script bridge diagnostics.");
   else {toggleTick=now;toggleQueued=true;}
  }
  wasDown=down;Sleep(16);
 }
}
static DWORD WINAPI initialize(void*) {
 wchar_t exe[MAX_PATH];GetModuleFileNameW(nullptr,exe,MAX_PATH);root=exe;root=root.substr(0,root.find_last_of(L"\\/")+1);
 iniPath=root+L"Data\\NVSE\\Plugins\\LukesActorBrowser.ini"; config();
 CreateDirectoryW((root+L"Data\\config").c_str(),nullptr);bridgePath=root+L"Data\\config\\LukesActorBrowserRuntime.ini";
 sessionToken=(GetTickCount()%900000)+100000;
 WritePrivateProfileStringW(L"Bridge",L"Session",std::to_wstring(sessionToken).c_str(),bridgePath.c_str());
 WritePrivateProfileStringW(L"Bridge",L"Ready",L"0",bridgePath.c_str());WritePrivateProfileStringW(L"Request",L"Pending",L"0",bridgePath.c_str());
 WritePrivateProfileStringW(L"Audio",L"Menu",L"0",bridgePath.c_str());nativeStatus(L"Frames",L"0");nativeStatus(L"Input",L"0");nativeStatus(L"Hooks",L"0");nativeStatus(L"Error",L"");config();
 auto z=LoadLibraryExW((root+L"Data\\NVSE\\Plugins\\LukesActorBrowser\\zlib1.dll").c_str(),nullptr,LOAD_LIBRARY_SEARCH_DLL_LOAD_DIR|LOAD_LIBRARY_SEARCH_SYSTEM32);if(z)inflateFn=(ib::Inflate)GetProcAddress(z,"uncompress");
 logLine("Luke's Actor Browser 1.0.12-native3: NVSEPlugin_Load entered; initialising native game menu.");
 if(!inflateFn)failNative("zlib1.dll could not be loaded; compressed item records unavailable");
 pad::initialize();
 bool input=hookImport(GetModuleHandleW(nullptr),"DirectInput8Create",(void*)inputFactoryHook,(void**)&originalInputFactory);
 if(!input){failNative("Game DirectInput8Create import not found; native menu cannot safely capture mouse input.");return 1;}
 logLine("Native-menu edition: input hooks installed; graphics hooks disabled.");
 return 0;
}
extern "C" __declspec(dllexport) bool NVSEPlugin_Query(const NVSEVersionPrefix* nvse,PluginInfo* info) {
 info->infoVersion=1;info->name="Luke's Actor Browser";info->version=112;
 wchar_t exe[MAX_PATH]{};GetModuleFileNameW(nullptr,exe,MAX_PATH);root=exe;root=root.substr(0,root.find_last_of(L"\\/")+1);
 if(!nvse){logLine("Query rejected: missing NVSE interface.");return false;}
 if(nvse->isEditor){logLine("Query rejected: this plugin runs in the game, not GECK.");return false;}
 if(nvse->runtimeVersion!=0x040020D0){logLine("Query rejected: unsupported game runtime (requires standard 1.4.0.525).");return false;}
 if(nvse->nvseVersion<6){logLine("Query rejected: xNVSE 6 or newer required.");return false;}
 logLine("Luke's Actor Browser 1.0.12-native3: runtime query accepted.");return true;
}
static void browserNVSEMessage(BrowserNVSEMessage* message){
 if(!message)return;
 // CompileScript dispatches ScriptCompile synchronously. Reject unrelated
 // messages BEFORE locking: that notification can re-enter during initialization.
 const bool lifecycle=message->type==1||message->type==2||message->type==6||message->type==7||message->type==14;
 if(message->type!=BrowserMainGameLoop&&!lifecycle)return;
 std::unique_lock<std::mutex> guard(catalogMutex);
 // Release on exit, main-menu return, loading or a new game. Never save control locks.
 if(lifecycle){
  opened=false;blockUntil=0;toggleQueued=false;controllerDecoder={};controlInitAttempts=0;controlRetryAt=0;nativeView.hide();nativeView.forget();nativeAttempts=0;nativeRetryAt=0;
  if(controlLease.release())releaseBrowser();
  return;
 }
 if(message->type!=BrowserMainGameLoop)return;
 nativeLoopActive=true;
 // Wait for this process's JIP load/new-game bridge, rather than compiling at
 // the first startup frame. Retry transient failures without compiling every frame.
 if(!controlsReady&&controlInitAttempts<3&&bridgeNumber(L"Bridge",L"Ready")==sessionToken&&
    (LONG)(GetTickCount()-controlRetryAt)>=0){
  ++controlInitAttempts;controlRetryAt=GetTickCount()+2000;
  bool helpers=controlButtons.initialize(controlScripts);
  if(helpers&&!menuModeScript)menuModeScript=controlScripts->compileExpression("MenuMode");
  controlsReady=helpers&&menuModeScript;
  controlLease.configure(controlAPI,&controlButtons,"LukesActorBrowser");
  nativeStatus(L"ControlsAPI",controlsReady?L"1":L"0");
  if(controlsReady){nativeStatus(L"Error",L"");logLine("Supported player-control APIs ready; no controller polling hook installed.");}
  else {
   std::string error=helpers?"Cannot compile query: MenuMode":controlButtons.lastError();
   logLine(error.c_str());nativeStatus(L"Error",wide(error).c_str());
  }
 }
 DWORD pid=0;GetWindowThreadProcessId(GetForegroundWindow(),&pid);
 bool foreground=pid==GetCurrentProcessId();
 bool frames=controlsReady&&nativeReady();
 if(opened&&(!foreground||!frames||gameMenuActive()))closeBrowser();
 if(!opened&&controlLease.active()&&(!foreground||!frames||((LONG)(GetTickCount()-blockUntil.load())>=0&&pad::allReleased()))){
  if(controlLease.release())releaseBrowser();
 }
 if(controlsReady&&foreground&&frames&&inputReady)inputs();
 if(frames)nativePaint();
}
extern "C" __declspec(dllexport) bool NVSEPlugin_Load(const NVSELoadInterface* nvse) {
 // Resolve the public interface before installing any browser hooks.
 controlAPI=nvse&&nvse->QueryInterface?(BrowserPlayerControls*)nvse->QueryInterface(10):nullptr;
 controlScripts=nvse&&nvse->QueryInterface?(BrowserScriptAPI*)nvse->QueryInterface(6):nullptr;
 auto messaging=nvse&&nvse->QueryInterface?(BrowserNVSEMessaging*)nvse->QueryInterface(BrowserMessagingInterface):nullptr;
 if(!controlAPI||!controlAPI->disable||!controlAPI->enable||!controlScripts||!messaging||messaging->version<4||!nvse->GetPluginHandle){
  logLine("Load rejected: supported player-control interface missing. Requires xNVSE 6.3.11 or newer.");return false;
 }
 if(initialize(nullptr)!=0)return false;
 if(!messaging->RegisterListener(nvse->GetPluginHandle(),"NVSE",browserNVSEMessage))
  logLine("ERROR: could not register control service. Menu opening disabled.");
 nativeStatus(L"ControllerGate",L"0");nativeStatus(L"ControlsAPI",L"0");
 // Runtime DLL remains loaded while its monitor and installed hooks are active.
 HMODULE pinned=nullptr;
 if(GetModuleHandleExW(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS|GET_MODULE_HANDLE_EX_FLAG_PIN,(LPCWSTR)&hotkeyMonitor,&pinned)) {
  monitorActive=true;HANDLE thread=CreateThread(nullptr,0,hotkeyMonitor,nullptr,0,nullptr);
  if(thread)CloseHandle(thread);else {monitorActive=false;failNative("Hotkey monitor could not start; using render-thread input fallback");}
 }else failNative("Could not pin plugin; using render-thread input fallback");
 return true;
}
BOOL WINAPI DllMain(HINSTANCE instance,DWORD reason,LPVOID) {if(reason==DLL_PROCESS_ATTACH){moduleHandle=instance;DisableThreadLibraryCalls(instance);}return TRUE;}
















